﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace t2_Grade_ClientApp
{
    public partial class frm物件導向程式設計: Form
    {
        public frm物件導向程式設計()
        {
            InitializeComponent();
        }
    }
}
