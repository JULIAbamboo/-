﻿namespace t2_Grade_ClientApp
{
    partial class frm測試表單_學生端
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm測試表單_學生端));
            this.btn1x58060 = new System.Windows.Forms.Button();
            this.btn13580xx = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn1x58060
            // 
            this.btn1x58060.Font = new System.Drawing.Font("微軟正黑體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn1x58060.Location = new System.Drawing.Point(33, 38);
            this.btn1x58060.Name = "btn1x58060";
            this.btn1x58060.Size = new System.Drawing.Size(137, 55);
            this.btn1x58060.TabIndex = 3;
            this.btn1x58060.Text = "1x58060";
            this.btn1x58060.UseVisualStyleBackColor = true;
            this.btn1x58060.Click += new System.EventHandler(this.btn1x58060_Click);
            // 
            // btn13580xx
            // 
            this.btn13580xx.Font = new System.Drawing.Font("微軟正黑體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn13580xx.Location = new System.Drawing.Point(203, 38);
            this.btn13580xx.Name = "btn13580xx";
            this.btn13580xx.Size = new System.Drawing.Size(137, 55);
            this.btn13580xx.TabIndex = 4;
            this.btn13580xx.Text = "13580xx";
            this.btn13580xx.UseVisualStyleBackColor = true;
            this.btn13580xx.Click += new System.EventHandler(this.btn13580xx_Click);
            // 
            // frm測試表單_學生端
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 131);
            this.Controls.Add(this.btn13580xx);
            this.Controls.Add(this.btn1x58060);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm測試表單_學生端";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "測試";
            this.Load += new System.EventHandler(this.frm測試表單_學生端_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn1x58060;
        private System.Windows.Forms.Button btn13580xx;
    }
}