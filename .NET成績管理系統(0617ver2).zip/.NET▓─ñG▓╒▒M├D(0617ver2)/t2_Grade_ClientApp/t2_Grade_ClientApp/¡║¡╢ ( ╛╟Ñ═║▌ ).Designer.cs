﻿namespace t2_Grade_ClientApp
{
    partial class frm首頁_學生端
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm首頁_學生端));
            this.panel_學生個人資料 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl姓名_個人資料 = new System.Windows.Forms.Label();
            this.lbl學號_個人資料 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbl2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.timer時間 = new System.Windows.Forms.Timer(this.components);
            this.lbl1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn課程2 = new System.Windows.Forms.Button();
            this.btn課程1 = new System.Windows.Forms.Button();
            this.btn重新載入 = new System.Windows.Forms.Button();
            this.txt公告 = new System.Windows.Forms.TextBox();
            this.lbl歡迎 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.lbl當前時間 = new System.Windows.Forms.Label();
            this.lbl上次 = new System.Windows.Forms.Label();
            this.btn登出 = new System.Windows.Forms.Button();
            this.panel_學生個人資料.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_學生個人資料
            // 
            this.panel_學生個人資料.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel_學生個人資料.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel_學生個人資料.Controls.Add(this.btn登出);
            this.panel_學生個人資料.Controls.Add(this.pictureBox1);
            this.panel_學生個人資料.Controls.Add(this.lbl姓名_個人資料);
            this.panel_學生個人資料.Controls.Add(this.lbl學號_個人資料);
            this.panel_學生個人資料.Controls.Add(this.label3);
            this.panel_學生個人資料.Controls.Add(this.pictureBox2);
            this.panel_學生個人資料.Location = new System.Drawing.Point(-4, -2);
            this.panel_學生個人資料.Name = "panel_學生個人資料";
            this.panel_學生個人資料.Size = new System.Drawing.Size(226, 479);
            this.panel_學生個人資料.TabIndex = 16;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(43, 143);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // lbl姓名_個人資料
            // 
            this.lbl姓名_個人資料.AutoSize = true;
            this.lbl姓名_個人資料.BackColor = System.Drawing.Color.White;
            this.lbl姓名_個人資料.Font = new System.Drawing.Font("微軟正黑體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl姓名_個人資料.Location = new System.Drawing.Point(36, 298);
            this.lbl姓名_個人資料.Name = "lbl姓名_個人資料";
            this.lbl姓名_個人資料.Size = new System.Drawing.Size(52, 22);
            this.lbl姓名_個人資料.TabIndex = 8;
            this.lbl姓名_個人資料.Text = "姓名 :";
            // 
            // lbl學號_個人資料
            // 
            this.lbl學號_個人資料.AutoSize = true;
            this.lbl學號_個人資料.BackColor = System.Drawing.Color.White;
            this.lbl學號_個人資料.Font = new System.Drawing.Font("微軟正黑體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl學號_個人資料.Location = new System.Drawing.Point(36, 340);
            this.lbl學號_個人資料.Name = "lbl學號_個人資料";
            this.lbl學號_個人資料.Size = new System.Drawing.Size(52, 22);
            this.lbl學號_個人資料.TabIndex = 9;
            this.lbl學號_個人資料.Text = "學號 :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(38, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 27);
            this.label3.TabIndex = 12;
            this.label3.Text = "👤 個人資料    ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Location = new System.Drawing.Point(-16, 108);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(240, 358);
            this.pictureBox2.TabIndex = 38;
            this.pictureBox2.TabStop = false;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl2.Location = new System.Drawing.Point(290, 42);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(76, 19);
            this.lbl2.TabIndex = 30;
            this.lbl2.Text = "當前時間 :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label9.Location = new System.Drawing.Point(253, 289);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(138, 24);
            this.label9.TabIndex = 28;
            this.label9.Text = " 課程成績查詢 :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.Location = new System.Drawing.Point(253, 159);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(166, 24);
            this.label10.TabIndex = 27;
            this.label10.Text = "🔔 成績預警通知：";
            // 
            // timer時間
            // 
            this.timer時間.Enabled = true;
            this.timer時間.Interval = 1000;
            this.timer時間.Tick += new System.EventHandler(this.timer時間_Tick);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl1.Location = new System.Drawing.Point(261, 9);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(106, 19);
            this.lbl1.TabIndex = 32;
            this.lbl1.Text = "上次登入時間 :";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.White;
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.OutsetPartial;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel2.Controls.Add(this.btn課程2, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.btn課程1, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(251, 318);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0, 5, 0, 5);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.Padding = new System.Windows.Forms.Padding(10);
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(328, 114);
            this.tableLayoutPanel2.TabIndex = 26;
            // 
            // btn課程2
            // 
            this.btn課程2.Font = new System.Drawing.Font("微軟正黑體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn課程2.Location = new System.Drawing.Point(16, 61);
            this.btn課程2.Name = "btn課程2";
            this.btn課程2.Size = new System.Drawing.Size(296, 37);
            this.btn課程2.TabIndex = 21;
            this.btn課程2.Text = "作業系統";
            this.btn課程2.UseVisualStyleBackColor = true;
            this.btn課程2.Click += new System.EventHandler(this.btn課程2_Click_1);
            // 
            // btn課程1
            // 
            this.btn課程1.Font = new System.Drawing.Font("微軟正黑體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn課程1.Location = new System.Drawing.Point(16, 16);
            this.btn課程1.Name = "btn課程1";
            this.btn課程1.Size = new System.Drawing.Size(296, 36);
            this.btn課程1.TabIndex = 20;
            this.btn課程1.Text = "網頁設計";
            this.btn課程1.UseVisualStyleBackColor = true;
            this.btn課程1.Click += new System.EventHandler(this.btn課程1_Click_1);
            // 
            // btn重新載入
            // 
            this.btn重新載入.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn重新載入.Location = new System.Drawing.Point(466, 201);
            this.btn重新載入.Name = "btn重新載入";
            this.btn重新載入.Size = new System.Drawing.Size(97, 48);
            this.btn重新載入.TabIndex = 40;
            this.btn重新載入.Text = "重新載入";
            this.btn重新載入.UseVisualStyleBackColor = true;
            this.btn重新載入.Click += new System.EventHandler(this.btn重新載入_Click);
            // 
            // txt公告
            // 
            this.txt公告.BackColor = System.Drawing.Color.White;
            this.txt公告.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt公告.Location = new System.Drawing.Point(257, 201);
            this.txt公告.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.txt公告.Multiline = true;
            this.txt公告.Name = "txt公告";
            this.txt公告.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txt公告.Size = new System.Drawing.Size(186, 48);
            this.txt公告.TabIndex = 41;
            // 
            // lbl歡迎
            // 
            this.lbl歡迎.AutoSize = true;
            this.lbl歡迎.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl歡迎.Location = new System.Drawing.Point(290, 76);
            this.lbl歡迎.Name = "lbl歡迎";
            this.lbl歡迎.Size = new System.Drawing.Size(84, 19);
            this.lbl歡迎.TabIndex = 42;
            this.lbl歡迎.Text = "歡迎登入，";
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.Location = new System.Drawing.Point(231, 108);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(377, 360);
            this.pictureBox3.TabIndex = 43;
            this.pictureBox3.TabStop = false;
            // 
            // lbl當前時間
            // 
            this.lbl當前時間.AutoSize = true;
            this.lbl當前時間.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl當前時間.Location = new System.Drawing.Point(375, 42);
            this.lbl當前時間.Name = "lbl當前時間";
            this.lbl當前時間.Size = new System.Drawing.Size(0, 19);
            this.lbl當前時間.TabIndex = 44;
            // 
            // lbl上次
            // 
            this.lbl上次.AutoSize = true;
            this.lbl上次.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl上次.Location = new System.Drawing.Point(375, 9);
            this.lbl上次.Name = "lbl上次";
            this.lbl上次.Size = new System.Drawing.Size(0, 19);
            this.lbl上次.TabIndex = 45;
            // 
            // btn登出
            // 
            this.btn登出.Font = new System.Drawing.Font("微軟正黑體", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn登出.Location = new System.Drawing.Point(75, 64);
            this.btn登出.Name = "btn登出";
            this.btn登出.Size = new System.Drawing.Size(68, 32);
            this.btn登出.TabIndex = 46;
            this.btn登出.Text = "登出";
            this.btn登出.UseVisualStyleBackColor = true;
            this.btn登出.Click += new System.EventHandler(this.btn登出_Click);
            // 
            // frm首頁_學生端
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(604, 466);
            this.Controls.Add(this.lbl上次);
            this.Controls.Add(this.lbl當前時間);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt公告);
            this.Controls.Add(this.btn重新載入);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lbl歡迎);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.panel_學生個人資料);
            this.Controls.Add(this.pictureBox3);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm首頁_學生端";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "首頁 ( 學生端 )";
            this.Load += new System.EventHandler(this.frm進入_學生端_Load);
            this.panel_學生個人資料.ResumeLayout(false);
            this.panel_學生個人資料.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel_學生個人資料;
        private System.Windows.Forms.Label lbl學號_個人資料;
        private System.Windows.Forms.Label lbl姓名_個人資料;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Timer timer時間;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Button btn課程2;
        private System.Windows.Forms.Button btn課程1;
        private System.Windows.Forms.Button btn重新載入;
        private System.Windows.Forms.TextBox txt公告;
        private System.Windows.Forms.Label lbl歡迎;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lbl當前時間;
        private System.Windows.Forms.Label lbl上次;
        private System.Windows.Forms.Button btn登出;
    }
}