﻿namespace t2_Grade_ClientApp
{
    partial class frm作業系統
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm作業系統));
            this.SidePanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btn成績查看 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl最低分 = new System.Windows.Forms.Label();
            this.lbl排名 = new System.Windows.Forms.Label();
            this.lbl最高分 = new System.Windows.Forms.Label();
            this.lbl平均分 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl總成績 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl無成績 = new System.Windows.Forms.Label();
            this.courseDescription21 = new t2_Grade_ClientApp.CourseDescription2();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.Gray;
            this.SidePanel.Location = new System.Drawing.Point(0, 79);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(10, 48);
            this.SidePanel.TabIndex = 100;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.SidePanel);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btn成績查看);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(196, 575);
            this.panel1.TabIndex = 102;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(0, 113);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(196, 48);
            this.button1.TabIndex = 94;
            this.button1.Text = "課程介紹";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn成績查看
            // 
            this.btn成績查看.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.btn成績查看.FlatAppearance.BorderSize = 0;
            this.btn成績查看.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn成績查看.Font = new System.Drawing.Font("微軟正黑體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn成績查看.ForeColor = System.Drawing.Color.White;
            this.btn成績查看.Location = new System.Drawing.Point(0, 56);
            this.btn成績查看.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btn成績查看.Name = "btn成績查看";
            this.btn成績查看.Size = new System.Drawing.Size(196, 48);
            this.btn成績查看.TabIndex = 93;
            this.btn成績查看.Text = "成績查看";
            this.btn成績查看.UseVisualStyleBackColor = false;
            this.btn成績查看.Click += new System.EventHandler(this.btn成績查看_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(321, 305);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 36);
            this.label5.TabIndex = 119;
            this.label5.Text = "班級情況";
            // 
            // lbl最低分
            // 
            this.lbl最低分.AutoSize = true;
            this.lbl最低分.BackColor = System.Drawing.Color.Transparent;
            this.lbl最低分.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl最低分.Location = new System.Drawing.Point(410, 439);
            this.lbl最低分.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl最低分.Name = "lbl最低分";
            this.lbl最低分.Size = new System.Drawing.Size(78, 33);
            this.lbl最低分.TabIndex = 118;
            this.lbl最低分.Text = "         ";
            // 
            // lbl排名
            // 
            this.lbl排名.AutoSize = true;
            this.lbl排名.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl排名.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl排名.Location = new System.Drawing.Point(795, 452);
            this.lbl排名.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl排名.Name = "lbl排名";
            this.lbl排名.Size = new System.Drawing.Size(57, 33);
            this.lbl排名.TabIndex = 112;
            this.lbl排名.Text = "      ";
            // 
            // lbl最高分
            // 
            this.lbl最高分.AutoSize = true;
            this.lbl最高分.BackColor = System.Drawing.Color.Transparent;
            this.lbl最高分.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl最高分.Location = new System.Drawing.Point(410, 384);
            this.lbl最高分.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl最高分.Name = "lbl最高分";
            this.lbl最高分.Size = new System.Drawing.Size(78, 33);
            this.lbl最高分.TabIndex = 117;
            this.lbl最高分.Text = "         ";
            // 
            // lbl平均分
            // 
            this.lbl平均分.AutoSize = true;
            this.lbl平均分.BackColor = System.Drawing.Color.Transparent;
            this.lbl平均分.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl平均分.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl平均分.Location = new System.Drawing.Point(435, 495);
            this.lbl平均分.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl平均分.Name = "lbl平均分";
            this.lbl平均分.Size = new System.Drawing.Size(78, 33);
            this.lbl平均分.TabIndex = 116;
            this.lbl平均分.Text = "         ";
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.BackColor = System.Drawing.Color.Transparent;
            this.lbl2.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl2.Location = new System.Drawing.Point(291, 439);
            this.lbl2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(99, 33);
            this.lbl2.TabIndex = 115;
            this.lbl2.Text = "最低分:";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.Color.Transparent;
            this.lbl1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl1.Location = new System.Drawing.Point(291, 384);
            this.lbl1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(99, 33);
            this.lbl1.TabIndex = 114;
            this.lbl1.Text = "最高分:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(734, 305);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 36);
            this.label8.TabIndex = 120;
            this.label8.Text = "個人";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.BackColor = System.Drawing.Color.Transparent;
            this.lbl3.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl3.Location = new System.Drawing.Point(291, 495);
            this.lbl3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(125, 33);
            this.lbl3.TabIndex = 113;
            this.lbl3.Text = "平均分數:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(290, 209);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 36);
            this.label2.TabIndex = 108;
            this.label2.Text = "教師: A老師   ";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl4.Location = new System.Drawing.Point(708, 384);
            this.lbl4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(99, 33);
            this.lbl4.TabIndex = 109;
            this.lbl4.Text = "總成績:";
            // 
            // lbl總成績
            // 
            this.lbl總成績.AutoSize = true;
            this.lbl總成績.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl總成績.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl總成績.Location = new System.Drawing.Point(822, 384);
            this.lbl總成績.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl總成績.Name = "lbl總成績";
            this.lbl總成績.Size = new System.Drawing.Size(57, 33);
            this.lbl總成績.TabIndex = 110;
            this.lbl總成績.Text = "      ";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl5.Location = new System.Drawing.Point(708, 452);
            this.lbl5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(73, 33);
            this.lbl5.TabIndex = 111;
            this.lbl5.Text = "排名:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(196, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(810, 28);
            this.panel2.TabIndex = 122;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(242, 56);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(201, 100);
            this.panel3.TabIndex = 123;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(30, 31);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(137, 38);
            this.label7.TabIndex = 78;
            this.label7.Text = "作業系統";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("標楷體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(254, 329);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(597, 26);
            this.label1.TabIndex = 124;
            this.label1.Text = "_____________________________________________";
            // 
            // lbl無成績
            // 
            this.lbl無成績.AutoSize = true;
            this.lbl無成績.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl無成績.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbl無成績.Location = new System.Drawing.Point(456, 439);
            this.lbl無成績.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl無成績.Name = "lbl無成績";
            this.lbl無成績.Size = new System.Drawing.Size(223, 33);
            this.lbl無成績.TabIndex = 125;
            this.lbl無成績.Text = "目前尚無成績顯示";
            // 
            // courseDescription21
            // 
            this.courseDescription21.AutoScroll = true;
            this.courseDescription21.Location = new System.Drawing.Point(196, 183);
            this.courseDescription21.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.courseDescription21.Name = "courseDescription21";
            this.courseDescription21.Size = new System.Drawing.Size(810, 395);
            this.courseDescription21.TabIndex = 121;
            // 
            // frm作業系統
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1006, 575);
            this.Controls.Add(this.courseDescription21);
            this.Controls.Add(this.lbl無成績);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl最低分);
            this.Controls.Add(this.lbl排名);
            this.Controls.Add(this.lbl最高分);
            this.Controls.Add(this.lbl平均分);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl總成績);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(196, 183);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frm作業系統";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "資訊-作業系統( 學生端 )";
            this.Activated += new System.EventHandler(this.frm第二門課程_Activated);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn成績查看;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl最低分;
        private System.Windows.Forms.Label lbl排名;
        private System.Windows.Forms.Label lbl最高分;
        private System.Windows.Forms.Label lbl平均分;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl總成績;
        private System.Windows.Forms.Label lbl5;
        private CourseDescription2 courseDescription21;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl無成績;
    }
}