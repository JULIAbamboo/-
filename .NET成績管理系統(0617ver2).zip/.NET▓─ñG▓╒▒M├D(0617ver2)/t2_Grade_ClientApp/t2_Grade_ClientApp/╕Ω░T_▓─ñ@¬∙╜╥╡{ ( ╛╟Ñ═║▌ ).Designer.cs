﻿namespace t2_Grade_ClientApp
{
    partial class frm網頁設計
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm網頁設計));
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.SidePanel = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btn成績查看 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.courseDescription1 = new t2_Grade_ClientApp.CourseDescription();
            this.lbl無成績 = new System.Windows.Forms.Label();
            this.lbl最低分 = new System.Windows.Forms.Label();
            this.lbl最高分 = new System.Windows.Forms.Label();
            this.lbl平均分 = new System.Windows.Forms.Label();
            this.lbl排名 = new System.Windows.Forms.Label();
            this.lbl總成績 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.BackColor = System.Drawing.Color.Transparent;
            this.lbl2.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl2.Location = new System.Drawing.Point(196, 314);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(71, 24);
            this.lbl2.TabIndex = 87;
            this.lbl2.Text = "最低分:";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.BackColor = System.Drawing.Color.Transparent;
            this.lbl1.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl1.Location = new System.Drawing.Point(196, 274);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(71, 24);
            this.lbl1.TabIndex = 86;
            this.lbl1.Text = "最高分:";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.BackColor = System.Drawing.Color.Transparent;
            this.lbl3.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl3.Location = new System.Drawing.Point(196, 357);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(71, 24);
            this.lbl3.TabIndex = 85;
            this.lbl3.Text = "平均分:";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl5.Location = new System.Drawing.Point(492, 320);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(52, 24);
            this.lbl5.TabIndex = 83;
            this.lbl5.Text = "排名:";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl4.Location = new System.Drawing.Point(473, 274);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(71, 24);
            this.lbl4.TabIndex = 81;
            this.lbl4.Text = "總成績:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(193, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 27);
            this.label2.TabIndex = 79;
            this.label2.Text = "教師: A老師   ";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(161, 42);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(134, 75);
            this.panel3.TabIndex = 103;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("微軟正黑體", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(20, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 28);
            this.label7.TabIndex = 78;
            this.label7.Text = "網頁設計";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel2.Location = new System.Drawing.Point(131, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(540, 21);
            this.panel2.TabIndex = 102;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.panel1.Controls.Add(this.SidePanel);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.btn成績查看);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(131, 437);
            this.panel1.TabIndex = 101;
            // 
            // SidePanel
            // 
            this.SidePanel.BackColor = System.Drawing.Color.Gray;
            this.SidePanel.Location = new System.Drawing.Point(0, 59);
            this.SidePanel.Margin = new System.Windows.Forms.Padding(2);
            this.SidePanel.Name = "SidePanel";
            this.SidePanel.Size = new System.Drawing.Size(7, 36);
            this.SidePanel.TabIndex = 100;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("微軟正黑體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(0, 85);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(131, 36);
            this.button1.TabIndex = 94;
            this.button1.Text = "課程介紹";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn成績查看
            // 
            this.btn成績查看.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(39)))), ((int)(((byte)(40)))));
            this.btn成績查看.FlatAppearance.BorderSize = 0;
            this.btn成績查看.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn成績查看.Font = new System.Drawing.Font("微軟正黑體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn成績查看.ForeColor = System.Drawing.Color.White;
            this.btn成績查看.Location = new System.Drawing.Point(0, 42);
            this.btn成績查看.Name = "btn成績查看";
            this.btn成績查看.Size = new System.Drawing.Size(131, 36);
            this.btn成績查看.TabIndex = 93;
            this.btn成績查看.Text = "成績查看";
            this.btn成績查看.UseVisualStyleBackColor = false;
            this.btn成績查看.Click += new System.EventHandler(this.btn課程首頁_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("標楷體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(173, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(459, 19);
            this.label1.TabIndex = 105;
            this.label1.Text = "_____________________________________________";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(215, 219);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 27);
            this.label5.TabIndex = 106;
            this.label5.Text = "班級情況";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(490, 219);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 27);
            this.label8.TabIndex = 107;
            this.label8.Text = "個人";
            // 
            // courseDescription1
            // 
            this.courseDescription1.AutoScroll = true;
            this.courseDescription1.Location = new System.Drawing.Point(131, 137);
            this.courseDescription1.Margin = new System.Windows.Forms.Padding(4);
            this.courseDescription1.Name = "courseDescription1";
            this.courseDescription1.Size = new System.Drawing.Size(540, 300);
            this.courseDescription1.TabIndex = 104;
            // 
            // lbl無成績
            // 
            this.lbl無成績.AutoSize = true;
            this.lbl無成績.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl無成績.ForeColor = System.Drawing.Color.DodgerBlue;
            this.lbl無成績.Location = new System.Drawing.Point(305, 314);
            this.lbl無成績.Name = "lbl無成績";
            this.lbl無成績.Size = new System.Drawing.Size(162, 24);
            this.lbl無成績.TabIndex = 108;
            this.lbl無成績.Text = "目前尚無成績顯示";
            // 
            // lbl最低分
            // 
            this.lbl最低分.AutoSize = true;
            this.lbl最低分.BackColor = System.Drawing.Color.Transparent;
            this.lbl最低分.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl最低分.Location = new System.Drawing.Point(273, 315);
            this.lbl最低分.Name = "lbl最低分";
            this.lbl最低分.Size = new System.Drawing.Size(55, 24);
            this.lbl最低分.TabIndex = 121;
            this.lbl最低分.Text = "         ";
            // 
            // lbl最高分
            // 
            this.lbl最高分.AutoSize = true;
            this.lbl最高分.BackColor = System.Drawing.Color.Transparent;
            this.lbl最高分.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl最高分.Location = new System.Drawing.Point(273, 274);
            this.lbl最高分.Name = "lbl最高分";
            this.lbl最高分.Size = new System.Drawing.Size(55, 24);
            this.lbl最高分.TabIndex = 120;
            this.lbl最高分.Text = "         ";
            // 
            // lbl平均分
            // 
            this.lbl平均分.AutoSize = true;
            this.lbl平均分.BackColor = System.Drawing.Color.Transparent;
            this.lbl平均分.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl平均分.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl平均分.Location = new System.Drawing.Point(290, 357);
            this.lbl平均分.Name = "lbl平均分";
            this.lbl平均分.Size = new System.Drawing.Size(55, 24);
            this.lbl平均分.TabIndex = 119;
            this.lbl平均分.Text = "         ";
            // 
            // lbl排名
            // 
            this.lbl排名.AutoSize = true;
            this.lbl排名.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl排名.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl排名.Location = new System.Drawing.Point(550, 321);
            this.lbl排名.Name = "lbl排名";
            this.lbl排名.Size = new System.Drawing.Size(40, 24);
            this.lbl排名.TabIndex = 123;
            this.lbl排名.Text = "      ";
            // 
            // lbl總成績
            // 
            this.lbl總成績.AutoSize = true;
            this.lbl總成績.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl總成績.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lbl總成績.Location = new System.Drawing.Point(550, 274);
            this.lbl總成績.Name = "lbl總成績";
            this.lbl總成績.Size = new System.Drawing.Size(40, 24);
            this.lbl總成績.TabIndex = 122;
            this.lbl總成績.Text = "      ";
            // 
            // frm網頁設計
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(671, 437);
            this.Controls.Add(this.courseDescription1);
            this.Controls.Add(this.lbl排名);
            this.Controls.Add(this.lbl總成績);
            this.Controls.Add(this.lbl無成績);
            this.Controls.Add(this.lbl最低分);
            this.Controls.Add(this.lbl最高分);
            this.Controls.Add(this.lbl平均分);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm網頁設計";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "資訊-網頁設計( 學生端 )";
            this.Activated += new System.EventHandler(this.frm第一門課程_Activated);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel SidePanel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn成績查看;
        private CourseDescription courseDescription1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl無成績;
        private System.Windows.Forms.Label lbl最低分;
        private System.Windows.Forms.Label lbl最高分;
        private System.Windows.Forms.Label lbl平均分;
        private System.Windows.Forms.Label lbl排名;
        private System.Windows.Forms.Label lbl總成績;
    }
}