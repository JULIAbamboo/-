﻿namespace homework_6_1358004
{
    partial class frm登入_學校端
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm登入_學校端));
            this.panel_帳號登入 = new System.Windows.Forms.Panel();
            this.btn換一個 = new System.Windows.Forms.Button();
            this.lbl驗證碼 = new System.Windows.Forms.Label();
            this.txt驗證碼 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn修改密碼 = new System.Windows.Forms.Button();
            this.btn登入 = new System.Windows.Forms.Button();
            this.txt密碼 = new System.Windows.Forms.TextBox();
            this.txt帳號 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl密碼 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem三條線 = new System.Windows.Forms.ToolStripMenuItem();
            this.測試入口TToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.使用說明HToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_確認舊密碼 = new System.Windows.Forms.Panel();
            this.btn取消修改 = new System.Windows.Forms.Button();
            this.btn確定 = new System.Windows.Forms.Button();
            this.txt舊密碼 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel_更改新密碼 = new System.Windows.Forms.Panel();
            this.btn完成 = new System.Windows.Forms.Button();
            this.txt再一次 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txt新密碼 = new System.Windows.Forms.TextBox();
            this.panel_帳號登入.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel_確認舊密碼.SuspendLayout();
            this.panel_更改新密碼.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_帳號登入
            // 
            this.panel_帳號登入.BackColor = System.Drawing.Color.White;
            this.panel_帳號登入.Controls.Add(this.btn換一個);
            this.panel_帳號登入.Controls.Add(this.lbl驗證碼);
            this.panel_帳號登入.Controls.Add(this.txt驗證碼);
            this.panel_帳號登入.Controls.Add(this.label4);
            this.panel_帳號登入.Controls.Add(this.label2);
            this.panel_帳號登入.Controls.Add(this.btn修改密碼);
            this.panel_帳號登入.Controls.Add(this.btn登入);
            this.panel_帳號登入.Controls.Add(this.txt密碼);
            this.panel_帳號登入.Controls.Add(this.txt帳號);
            this.panel_帳號登入.Controls.Add(this.label3);
            this.panel_帳號登入.Controls.Add(this.lbl密碼);
            this.panel_帳號登入.Controls.Add(this.label1);
            this.panel_帳號登入.Location = new System.Drawing.Point(380, 42);
            this.panel_帳號登入.Name = "panel_帳號登入";
            this.panel_帳號登入.Size = new System.Drawing.Size(280, 362);
            this.panel_帳號登入.TabIndex = 11;
            // 
            // btn換一個
            // 
            this.btn換一個.BackColor = System.Drawing.Color.LightSlateGray;
            this.btn換一個.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn換一個.Font = new System.Drawing.Font("新細明體-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn換一個.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn換一個.Location = new System.Drawing.Point(49, 265);
            this.btn換一個.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btn換一個.Name = "btn換一個";
            this.btn換一個.Size = new System.Drawing.Size(90, 32);
            this.btn換一個.TabIndex = 16;
            this.btn換一個.Text = "換一個";
            this.btn換一個.UseVisualStyleBackColor = false;
            this.btn換一個.Click += new System.EventHandler(this.btn換一個_Click);
            // 
            // lbl驗證碼
            // 
            this.lbl驗證碼.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl驗證碼.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl驗證碼.Location = new System.Drawing.Point(159, 265);
            this.lbl驗證碼.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbl驗證碼.Name = "lbl驗證碼";
            this.lbl驗證碼.Size = new System.Drawing.Size(79, 26);
            this.lbl驗證碼.TabIndex = 12;
            this.lbl驗證碼.Text = "                     ";
            // 
            // txt驗證碼
            // 
            this.txt驗證碼.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt驗證碼.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt驗證碼.Location = new System.Drawing.Point(119, 189);
            this.txt驗證碼.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.txt驗證碼.Name = "txt驗證碼";
            this.txt驗證碼.Size = new System.Drawing.Size(119, 30);
            this.txt驗證碼.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(36, 187);
            this.label4.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 19);
            this.label4.TabIndex = 10;
            this.label4.Text = "驗證碼:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("新細明體-ExtB", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.ForeColor = System.Drawing.Color.LightSlateGray;
            this.label2.Location = new System.Drawing.Point(89, 35);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 24);
            this.label2.TabIndex = 9;
            this.label2.Text = "帳號登入";
            // 
            // btn修改密碼
            // 
            this.btn修改密碼.BackColor = System.Drawing.Color.LightSlateGray;
            this.btn修改密碼.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn修改密碼.Font = new System.Drawing.Font("新細明體-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn修改密碼.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn修改密碼.Location = new System.Drawing.Point(51, 307);
            this.btn修改密碼.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btn修改密碼.Name = "btn修改密碼";
            this.btn修改密碼.Size = new System.Drawing.Size(90, 32);
            this.btn修改密碼.TabIndex = 8;
            this.btn修改密碼.Text = "修改密碼";
            this.btn修改密碼.UseVisualStyleBackColor = false;
            this.btn修改密碼.Click += new System.EventHandler(this.btn修改密碼_Click);
            // 
            // btn登入
            // 
            this.btn登入.BackColor = System.Drawing.Color.LightSlateGray;
            this.btn登入.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn登入.Font = new System.Drawing.Font("新細明體-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn登入.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn登入.Location = new System.Drawing.Point(175, 307);
            this.btn登入.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btn登入.Name = "btn登入";
            this.btn登入.Size = new System.Drawing.Size(63, 32);
            this.btn登入.TabIndex = 6;
            this.btn登入.Text = "登入";
            this.btn登入.UseVisualStyleBackColor = false;
            this.btn登入.Click += new System.EventHandler(this.btn登入_Click);
            // 
            // txt密碼
            // 
            this.txt密碼.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt密碼.Location = new System.Drawing.Point(119, 138);
            this.txt密碼.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.txt密碼.Name = "txt密碼";
            this.txt密碼.Size = new System.Drawing.Size(119, 30);
            this.txt密碼.TabIndex = 5;
            this.txt密碼.UseSystemPasswordChar = true;
            // 
            // txt帳號
            // 
            this.txt帳號.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt帳號.Location = new System.Drawing.Point(119, 84);
            this.txt帳號.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.txt帳號.Name = "txt帳號";
            this.txt帳號.Size = new System.Drawing.Size(119, 30);
            this.txt帳號.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("細明體-ExtB", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(5, 147);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 19);
            this.label3.TabIndex = 3;
            // 
            // lbl密碼
            // 
            this.lbl密碼.AutoSize = true;
            this.lbl密碼.Font = new System.Drawing.Font("細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl密碼.Location = new System.Drawing.Point(55, 138);
            this.lbl密碼.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lbl密碼.Name = "lbl密碼";
            this.lbl密碼.Size = new System.Drawing.Size(59, 19);
            this.lbl密碼.TabIndex = 2;
            this.lbl密碼.Text = "密碼:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(55, 87);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "帳號:";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem三條線,
            this.使用說明HToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(694, 24);
            this.menuStrip1.TabIndex = 17;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem三條線
            // 
            this.toolStripMenuItem三條線.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.測試入口TToolStripMenuItem});
            this.toolStripMenuItem三條線.Name = "toolStripMenuItem三條線";
            this.toolStripMenuItem三條線.Size = new System.Drawing.Size(30, 20);
            this.toolStripMenuItem三條線.Text = "☰";
            // 
            // 測試入口TToolStripMenuItem
            // 
            this.測試入口TToolStripMenuItem.Font = new System.Drawing.Font("新細明體-ExtB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.測試入口TToolStripMenuItem.Name = "測試入口TToolStripMenuItem";
            this.測試入口TToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.測試入口TToolStripMenuItem.Text = "測試入口(&T)";
            this.測試入口TToolStripMenuItem.Click += new System.EventHandler(this.測試入口TToolStripMenuItem_Click);
            // 
            // 使用說明HToolStripMenuItem1
            // 
            this.使用說明HToolStripMenuItem1.Font = new System.Drawing.Font("新細明體-ExtB", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.使用說明HToolStripMenuItem1.Name = "使用說明HToolStripMenuItem1";
            this.使用說明HToolStripMenuItem1.Size = new System.Drawing.Size(88, 20);
            this.使用說明HToolStripMenuItem1.Text = "使用說明(&H)";
            this.使用說明HToolStripMenuItem1.Click += new System.EventHandler(this.使用說明HToolStripMenuItem1_Click);
            // 
            // panel_確認舊密碼
            // 
            this.panel_確認舊密碼.Controls.Add(this.btn取消修改);
            this.panel_確認舊密碼.Controls.Add(this.btn確定);
            this.panel_確認舊密碼.Controls.Add(this.txt舊密碼);
            this.panel_確認舊密碼.Controls.Add(this.label5);
            this.panel_確認舊密碼.Location = new System.Drawing.Point(27, 42);
            this.panel_確認舊密碼.Name = "panel_確認舊密碼";
            this.panel_確認舊密碼.Size = new System.Drawing.Size(325, 144);
            this.panel_確認舊密碼.TabIndex = 18;
            // 
            // btn取消修改
            // 
            this.btn取消修改.BackColor = System.Drawing.Color.LightSlateGray;
            this.btn取消修改.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn取消修改.Font = new System.Drawing.Font("新細明體-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn取消修改.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn取消修改.Location = new System.Drawing.Point(59, 81);
            this.btn取消修改.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btn取消修改.Name = "btn取消修改";
            this.btn取消修改.Size = new System.Drawing.Size(90, 32);
            this.btn取消修改.TabIndex = 15;
            this.btn取消修改.Text = "取消修改";
            this.btn取消修改.UseVisualStyleBackColor = false;
            this.btn取消修改.Click += new System.EventHandler(this.btn取消修改_Click);
            // 
            // btn確定
            // 
            this.btn確定.BackColor = System.Drawing.Color.LightSlateGray;
            this.btn確定.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn確定.Font = new System.Drawing.Font("新細明體-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn確定.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn確定.Location = new System.Drawing.Point(172, 81);
            this.btn確定.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btn確定.Name = "btn確定";
            this.btn確定.Size = new System.Drawing.Size(90, 32);
            this.btn確定.TabIndex = 13;
            this.btn確定.Text = "確定";
            this.btn確定.UseVisualStyleBackColor = false;
            this.btn確定.Click += new System.EventHandler(this.btn確定_Click_1);
            // 
            // txt舊密碼
            // 
            this.txt舊密碼.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt舊密碼.Location = new System.Drawing.Point(172, 29);
            this.txt舊密碼.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.txt舊密碼.Name = "txt舊密碼";
            this.txt舊密碼.Size = new System.Drawing.Size(119, 30);
            this.txt舊密碼.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(31, 31);
            this.label5.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 19);
            this.label5.TabIndex = 11;
            this.label5.Text = "請輸入舊密碼:";
            // 
            // panel_更改新密碼
            // 
            this.panel_更改新密碼.Controls.Add(this.btn完成);
            this.panel_更改新密碼.Controls.Add(this.txt再一次);
            this.panel_更改新密碼.Controls.Add(this.label7);
            this.panel_更改新密碼.Controls.Add(this.label8);
            this.panel_更改新密碼.Controls.Add(this.txt新密碼);
            this.panel_更改新密碼.Location = new System.Drawing.Point(27, 212);
            this.panel_更改新密碼.Name = "panel_更改新密碼";
            this.panel_更改新密碼.Size = new System.Drawing.Size(325, 192);
            this.panel_更改新密碼.TabIndex = 14;
            // 
            // btn完成
            // 
            this.btn完成.BackColor = System.Drawing.Color.LightSlateGray;
            this.btn完成.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn完成.Font = new System.Drawing.Font("新細明體-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn完成.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.btn完成.Location = new System.Drawing.Point(196, 137);
            this.btn完成.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btn完成.Name = "btn完成";
            this.btn完成.Size = new System.Drawing.Size(90, 32);
            this.btn完成.TabIndex = 10;
            this.btn完成.Text = "完成";
            this.btn完成.UseVisualStyleBackColor = false;
            this.btn完成.Click += new System.EventHandler(this.btn完成_Click);
            // 
            // txt再一次
            // 
            this.txt再一次.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt再一次.Location = new System.Drawing.Point(172, 81);
            this.txt再一次.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.txt再一次.Name = "txt再一次";
            this.txt再一次.Size = new System.Drawing.Size(119, 30);
            this.txt再一次.TabIndex = 9;
            this.txt再一次.UseSystemPasswordChar = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(31, 38);
            this.label7.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 19);
            this.label7.TabIndex = 6;
            this.label7.Text = "請輸入新密碼:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(50, 83);
            this.label8.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 19);
            this.label8.TabIndex = 8;
            this.label8.Text = "再輸入一次:";
            // 
            // txt新密碼
            // 
            this.txt新密碼.Font = new System.Drawing.Font("新細明體-ExtB", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txt新密碼.Location = new System.Drawing.Point(172, 36);
            this.txt新密碼.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.txt新密碼.Name = "txt新密碼";
            this.txt新密碼.Size = new System.Drawing.Size(119, 30);
            this.txt新密碼.TabIndex = 7;
            this.txt新密碼.UseSystemPasswordChar = true;
            // 
            // frm登入_學校端
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 423);
            this.Controls.Add(this.panel_確認舊密碼);
            this.Controls.Add(this.panel_更改新密碼);
            this.Controls.Add(this.panel_帳號登入);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frm登入_學校端";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "使用者登入 ( 學校端 )";
            this.Load += new System.EventHandler(this.frm登入_學校端_Load);
            this.panel_帳號登入.ResumeLayout(false);
            this.panel_帳號登入.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel_確認舊密碼.ResumeLayout(false);
            this.panel_確認舊密碼.PerformLayout();
            this.panel_更改新密碼.ResumeLayout(false);
            this.panel_更改新密碼.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_帳號登入;
        private System.Windows.Forms.Label lbl驗證碼;
        private System.Windows.Forms.TextBox txt驗證碼;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn修改密碼;
        private System.Windows.Forms.Button btn登入;
        private System.Windows.Forms.TextBox txt密碼;
        private System.Windows.Forms.TextBox txt帳號;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl密碼;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem三條線;
        private System.Windows.Forms.Panel panel_確認舊密碼;
        private System.Windows.Forms.Button btn完成;
        private System.Windows.Forms.TextBox txt再一次;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt新密碼;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt舊密碼;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel_更改新密碼;
        private System.Windows.Forms.Button btn確定;
        private System.Windows.Forms.Button btn換一個;
        private System.Windows.Forms.ToolStripMenuItem 使用說明HToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 測試入口TToolStripMenuItem;
        private System.Windows.Forms.Button btn取消修改;
    }
}