﻿namespace homework_6_1358004
{
    partial class frm首頁_學校端
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm首頁_學校端));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.btn成績管理 = new System.Windows.Forms.Button();
            this.panel_首頁資料 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.btn成績計算 = new System.Windows.Forms.Button();
            this.btn發布公告 = new System.Windows.Forms.Button();
            this.comboBox選擇課程 = new System.Windows.Forms.ComboBox();
            this.panel_成績表 = new System.Windows.Forms.Panel();
            this.btn刷新資料 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbl平均 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl最低分 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl最高分 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridView總表一覽 = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem三條橫線 = new System.Windows.Forms.ToolStripMenuItem();
            this.說明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.背景顏色CToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.藍色BToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.紅色RToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.綠色GToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.預設PToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.登出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_首頁資料.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.panel_成績表.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView總表一覽)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(62, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "成績計算";
            // 
            // btn成績管理
            // 
            this.btn成績管理.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn成績管理.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn成績管理.Location = new System.Drawing.Point(384, 37);
            this.btn成績管理.Name = "btn成績管理";
            this.btn成績管理.Size = new System.Drawing.Size(126, 30);
            this.btn成績管理.TabIndex = 1;
            this.btn成績管理.Text = "成績管理";
            this.btn成績管理.UseVisualStyleBackColor = true;
            this.btn成績管理.Click += new System.EventHandler(this.btn成績管理_Click);
            // 
            // panel_首頁資料
            // 
            this.panel_首頁資料.BackColor = System.Drawing.Color.LightGray;
            this.panel_首頁資料.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel_首頁資料.Controls.Add(this.label10);
            this.panel_首頁資料.Controls.Add(this.label2);
            this.panel_首頁資料.Controls.Add(this.pictureBox);
            this.panel_首頁資料.Controls.Add(this.btn成績計算);
            this.panel_首頁資料.Controls.Add(this.btn發布公告);
            this.panel_首頁資料.Controls.Add(this.comboBox選擇課程);
            this.panel_首頁資料.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.panel_首頁資料.Location = new System.Drawing.Point(-10, 27);
            this.panel_首頁資料.Name = "panel_首頁資料";
            this.panel_首頁資料.Size = new System.Drawing.Size(278, 575);
            this.panel_首頁資料.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("新細明體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(53, 285);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(152, 17);
            this.label10.TabIndex = 16;
            this.label10.Text = "*請在此先選擇課程";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("新細明體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(63, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 19);
            this.label2.TabIndex = 18;
            this.label2.Text = " 歡迎，A老師 ";
            // 
            // pictureBox
            // 
            this.pictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox.BackgroundImage")));
            this.pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox.Location = new System.Drawing.Point(55, 29);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(127, 133);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox.TabIndex = 18;
            this.pictureBox.TabStop = false;
            // 
            // btn成績計算
            // 
            this.btn成績計算.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn成績計算.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn成績計算.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn成績計算.Location = new System.Drawing.Point(52, 351);
            this.btn成績計算.Name = "btn成績計算";
            this.btn成績計算.Size = new System.Drawing.Size(156, 52);
            this.btn成績計算.TabIndex = 24;
            this.btn成績計算.Text = "📊 成績計算";
            this.btn成績計算.UseVisualStyleBackColor = false;
            this.btn成績計算.Click += new System.EventHandler(this.btn成績計算_Click);
            // 
            // btn發布公告
            // 
            this.btn發布公告.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btn發布公告.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn發布公告.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn發布公告.Location = new System.Drawing.Point(52, 441);
            this.btn發布公告.Name = "btn發布公告";
            this.btn發布公告.Size = new System.Drawing.Size(156, 51);
            this.btn發布公告.TabIndex = 19;
            this.btn發布公告.Text = "📢 發布預警";
            this.btn發布公告.UseVisualStyleBackColor = false;
            this.btn發布公告.Click += new System.EventHandler(this.btn發布公告_Click);
            // 
            // comboBox選擇課程
            // 
            this.comboBox選擇課程.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.comboBox選擇課程.Font = new System.Drawing.Font("新細明體", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox選擇課程.FormattingEnabled = true;
            this.comboBox選擇課程.Items.AddRange(new object[] {
            "網頁設計",
            "作業系統"});
            this.comboBox選擇課程.Location = new System.Drawing.Point(52, 249);
            this.comboBox選擇課程.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox選擇課程.Name = "comboBox選擇課程";
            this.comboBox選擇課程.Size = new System.Drawing.Size(146, 25);
            this.comboBox選擇課程.TabIndex = 23;
            this.comboBox選擇課程.Text = "選擇課程";
            this.comboBox選擇課程.SelectedIndexChanged += new System.EventHandler(this.comboBox選擇課程_SelectedIndexChanged);
            // 
            // panel_成績表
            // 
            this.panel_成績表.Controls.Add(this.btn刷新資料);
            this.panel_成績表.Controls.Add(this.groupBox1);
            this.panel_成績表.Controls.Add(this.label8);
            this.panel_成績表.Controls.Add(this.dataGridView總表一覽);
            this.panel_成績表.Controls.Add(this.label1);
            this.panel_成績表.Controls.Add(this.btn成績管理);
            this.panel_成績表.Location = new System.Drawing.Point(0, 27);
            this.panel_成績表.Name = "panel_成績表";
            this.panel_成績表.Size = new System.Drawing.Size(651, 563);
            this.panel_成績表.TabIndex = 18;
            this.panel_成績表.Visible = false;
            // 
            // btn刷新資料
            // 
            this.btn刷新資料.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn刷新資料.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn刷新資料.Location = new System.Drawing.Point(520, 37);
            this.btn刷新資料.Name = "btn刷新資料";
            this.btn刷新資料.Size = new System.Drawing.Size(93, 30);
            this.btn刷新資料.TabIndex = 19;
            this.btn刷新資料.Text = "↻刷新";
            this.btn刷新資料.UseVisualStyleBackColor = true;
            this.btn刷新資料.Click += new System.EventHandler(this.btn刷新資料_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbl平均);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.lbl最低分);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.lbl最高分);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Font = new System.Drawing.Font("新細明體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(354, 323);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(259, 206);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "成績情形一覽";
            // 
            // lbl平均
            // 
            this.lbl平均.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl平均.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl平均.Location = new System.Drawing.Point(141, 61);
            this.lbl平均.Name = "lbl平均";
            this.lbl平均.Size = new System.Drawing.Size(86, 29);
            this.lbl平均.TabIndex = 10;
            this.lbl平均.Text = "                    ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(26, 62);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "平均分數:";
            // 
            // lbl最低分
            // 
            this.lbl最低分.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl最低分.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl最低分.Location = new System.Drawing.Point(141, 144);
            this.lbl最低分.Name = "lbl最低分";
            this.lbl最低分.Size = new System.Drawing.Size(86, 32);
            this.lbl最低分.TabIndex = 12;
            this.lbl最低分.Text = "                    ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(46, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "最高分:";
            // 
            // lbl最高分
            // 
            this.lbl最高分.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl最高分.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl最高分.Location = new System.Drawing.Point(141, 103);
            this.lbl最高分.Name = "lbl最高分";
            this.lbl最高分.Size = new System.Drawing.Size(86, 32);
            this.lbl最高分.TabIndex = 11;
            this.lbl最高分.Text = "                    ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("新細明體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(46, 146);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 19);
            this.label6.TabIndex = 9;
            this.label6.Text = "最低分:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label8.Font = new System.Drawing.Font("微軟正黑體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.Location = new System.Drawing.Point(34, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 34);
            this.label8.TabIndex = 13;
            this.label8.Text = " ";
            // 
            // dataGridView總表一覽
            // 
            this.dataGridView總表一覽.AllowUserToAddRows = false;
            this.dataGridView總表一覽.AllowUserToDeleteRows = false;
            this.dataGridView總表一覽.AllowUserToOrderColumns = true;
            this.dataGridView總表一覽.AllowUserToResizeColumns = false;
            this.dataGridView總表一覽.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridView總表一覽.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView總表一覽.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("標楷體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView總表一覽.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView總表一覽.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView總表一覽.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Column1,
            this.Column3});
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("標楷體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView總表一覽.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView總表一覽.Location = new System.Drawing.Point(30, 112);
            this.dataGridView總表一覽.Name = "dataGridView總表一覽";
            this.dataGridView總表一覽.ReadOnly = true;
            this.dataGridView總表一覽.RowHeadersVisible = false;
            this.dataGridView總表一覽.RowHeadersWidth = 82;
            this.dataGridView總表一覽.RowTemplate.Height = 24;
            this.dataGridView總表一覽.Size = new System.Drawing.Size(583, 178);
            this.dataGridView總表一覽.TabIndex = 5;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "學號";
            this.Column2.MinimumWidth = 10;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 200;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "姓名";
            this.Column1.MinimumWidth = 10;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 200;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "總成績";
            this.Column3.MinimumWidth = 10;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 200;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem三條橫線,
            this.說明ToolStripMenuItem,
            this.背景顏色CToolStripMenuItem,
            this.登出ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(651, 24);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem三條橫線
            // 
            this.toolStripMenuItem三條橫線.Name = "toolStripMenuItem三條橫線";
            this.toolStripMenuItem三條橫線.Size = new System.Drawing.Size(30, 20);
            this.toolStripMenuItem三條橫線.Text = "☰";
            this.toolStripMenuItem三條橫線.Click += new System.EventHandler(this.toolStripMenuItem三條橫線_Click);
            // 
            // 說明ToolStripMenuItem
            // 
            this.說明ToolStripMenuItem.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.說明ToolStripMenuItem.Name = "說明ToolStripMenuItem";
            this.說明ToolStripMenuItem.Size = new System.Drawing.Size(108, 20);
            this.說明ToolStripMenuItem.Text = "使用說明 (&H)";
            this.說明ToolStripMenuItem.Click += new System.EventHandler(this.說明ToolStripMenuItem_Click);
            // 
            // 背景顏色CToolStripMenuItem
            // 
            this.背景顏色CToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.藍色BToolStripMenuItem,
            this.紅色RToolStripMenuItem,
            this.綠色GToolStripMenuItem,
            this.預設PToolStripMenuItem});
            this.背景顏色CToolStripMenuItem.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.背景顏色CToolStripMenuItem.Name = "背景顏色CToolStripMenuItem";
            this.背景顏色CToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.背景顏色CToolStripMenuItem.Text = "背景顏色(&C)";
            // 
            // 藍色BToolStripMenuItem
            // 
            this.藍色BToolStripMenuItem.Name = "藍色BToolStripMenuItem";
            this.藍色BToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.藍色BToolStripMenuItem.Text = "藍色(B)";
            this.藍色BToolStripMenuItem.Click += new System.EventHandler(this.藍色BToolStripMenuItem_Click);
            // 
            // 紅色RToolStripMenuItem
            // 
            this.紅色RToolStripMenuItem.Name = "紅色RToolStripMenuItem";
            this.紅色RToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.紅色RToolStripMenuItem.Text = "紅色(R)";
            this.紅色RToolStripMenuItem.Click += new System.EventHandler(this.紅色RToolStripMenuItem_Click);
            // 
            // 綠色GToolStripMenuItem
            // 
            this.綠色GToolStripMenuItem.Name = "綠色GToolStripMenuItem";
            this.綠色GToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.綠色GToolStripMenuItem.Text = "綠色(G)";
            this.綠色GToolStripMenuItem.Click += new System.EventHandler(this.綠色GToolStripMenuItem_Click);
            // 
            // 預設PToolStripMenuItem
            // 
            this.預設PToolStripMenuItem.Name = "預設PToolStripMenuItem";
            this.預設PToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.預設PToolStripMenuItem.Text = "預設(P)";
            this.預設PToolStripMenuItem.Click += new System.EventHandler(this.預設PToolStripMenuItem_Click);
            // 
            // 登出ToolStripMenuItem
            // 
            this.登出ToolStripMenuItem.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.登出ToolStripMenuItem.Name = "登出ToolStripMenuItem";
            this.登出ToolStripMenuItem.Size = new System.Drawing.Size(70, 20);
            this.登出ToolStripMenuItem.Text = "登出(&E)";
            this.登出ToolStripMenuItem.Click += new System.EventHandler(this.登出ToolStripMenuItem_Click);
            // 
            // frm首頁_學校端
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 589);
            this.Controls.Add(this.panel_首頁資料);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel_成績表);
            this.Font = new System.Drawing.Font("標楷體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frm首頁_學校端";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "首頁 ( 學校端 )";
            this.Load += new System.EventHandler(this.frm首頁_學校端_Load);
            this.panel_首頁資料.ResumeLayout(false);
            this.panel_首頁資料.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.panel_成績表.ResumeLayout(false);
            this.panel_成績表.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView總表一覽)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn成績管理;
        private System.Windows.Forms.Panel panel_首頁資料;
        private System.Windows.Forms.ComboBox comboBox選擇課程;
        private System.Windows.Forms.Button btn成績計算;
        private System.Windows.Forms.Button btn發布公告;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel_成績表;
        private System.Windows.Forms.DataGridView dataGridView總表一覽;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem三條橫線;
        private System.Windows.Forms.ToolStripMenuItem 說明ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 背景顏色CToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 藍色BToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 紅色RToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 綠色GToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 預設PToolStripMenuItem;
        private System.Windows.Forms.Label lbl最低分;
        private System.Windows.Forms.Label lbl最高分;
        private System.Windows.Forms.Label lbl平均;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ToolStripMenuItem 登出ToolStripMenuItem;
        private System.Windows.Forms.Button btn刷新資料;
    }
}