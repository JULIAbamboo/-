﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;
using Share_ClassLibrary;  // 引入 Share_ClassLibrary 命名空間


namespace homework_6_1358004
{
    public partial class frm學生建檔 : Form
    {

        string 暫存圖片路徑 = "";


        public frm學生建檔()
        {
            InitializeComponent();
        }

        private void frm學生建檔_Load(object sender, EventArgs e)
        {
            
            cboName.Items.Clear();

            Share_Data.設定預設資料();

            for (int i = 0; i < Share.S_i; i++)
            {
                cboName.Items.Add(Share.S_Names_array[i]);
            }
        }

        private void btn選擇檔案_Click_1(object sender, EventArgs e)
        {
            Dialog打開資料夾.Filter = "圖片檔|*.jpg;*.jpeg;*.png";

            if (Dialog打開資料夾.ShowDialog() == DialogResult.OK)
            {
                Image img = Image.FromFile(Dialog打開資料夾.FileName);

                pictureBox.BackgroundImage = img;

                lbl_尺寸.Text = img.Width + " x " + img.Height;

                // 顯示圖片的檔案大小（KB）
                FileInfo info = new FileInfo(Dialog打開資料夾.FileName); // 取得檔案資訊

                long fileSize = info.Length; // 單位是位元組(Byte)
                double kb = fileSize / 1024.0; // 換算成KB
                lbl_大小.Text = kb.ToString("F2") + " KB";
            }
        }

        private void panel1_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }


        private void panel1_DragDrop(object sender, DragEventArgs e)
        {
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);

            if (files.Length > 0)
            {
                暫存圖片路徑 = files[0];
                pictureBox.BackgroundImage = Image.FromFile(暫存圖片路徑);

                Image img = Image.FromFile(暫存圖片路徑);

                // 顯示圖片的寬和高（像素）
                lbl_尺寸.Text = img.Width + " x " + img.Height;

                // 顯示圖片的檔案大小（KB）
                FileInfo info = new FileInfo(暫存圖片路徑); // 取得檔案資訊

                long fileSize = info.Length; // 單位是位元組(Byte)
                double kb = fileSize / 1024.0; // 換算成KB
                lbl_大小.Text = kb.ToString("F2") + " KB";
            }
        }

        /// -------其他------------------------------------------///

        private void 回至開發人員測試頁面ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm開發人員測試 開發人員測試 = new frm開發人員測試();
            開發人員測試.Show();
        }

        /// -------當儲存鍵被按下--------------------------------------///

        //設定 ComboBox 的 DropDownStyle 為 DropDown 允許使用者輸入新資料，而不僅限於選擇預設項目。
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
           

            string[] 取得選取課程()
            {
                string[] 選之課程 = new string[2];  // 假設最多選兩門課程
                int 一人課程數 = 0;

                if (checkBox第一門課程.Checked && 一人課程數 < 2)
                {
                    選之課程[一人課程數++] = "第一門課程";
                }
                if (checkBox第二門課程.Checked && 一人課程數 < 2)
                {
                    選之課程[一人課程數++] = "第二門課程";
                }
                if (checkBox第三門課程.Checked && 一人課程數 < 2)
                {
                    選之課程[一人課程數++] = "第三門課程";
                }
                if (checkBox第四門課程.Checked && 一人課程數 < 2)
                {
                    選之課程[一人課程數++] = "第四門課程";
                }
                if (checkBox第五門課程.Checked && 一人課程數 < 2)
                {
                    選之課程[一人課程數++] = "第五門課程";
                }

                return 選之課程;
            }

            void 儲存選課(string[] 目前選課, int 存入索引)
            {
                // 儲存進 Share 陣列
                for (int i_存課索引 = 0; i_存課索引 < 2; i_存課索引++)
                {
                    if (i_存課索引 < 目前選課.Length && 目前選課[i_存課索引] != null)
                    {
                        Share.S_Courses_array[存入索引, i_存課索引] = 目前選課[i_存課索引];
                    }
                    else
                    {
                        Share.S_Courses_array[存入索引, i_存課索引] = "";  // 沒有選的課程留空
                    }
                }

                // 使用 if 判斷每個課程並更新人數
                if (目前選課[0] == "第一門課程")
                    Share.第一門課程人數++;

                if (目前選課[0] == "第二門課程")
                    Share.第二門課程人數++;

                if (目前選課[0] == "第三門課程")
                    Share.第三門課程人數++;

                if (目前選課[0] == "第四門課程")
                    Share.第四門課程人數++;

                if (目前選課[0] == "第五門課程")
                    Share.第五門課程人數++;

                if (目前選課[1] == "第一門課程")
                    Share.第一門課程人數++;

                if (目前選課[1] == "第二門課程")
                    Share.第二門課程人數++;

                if (目前選課[1] == "第三門課程")
                    Share.第三門課程人數++;

                if (目前選課[1] == "第四門課程")
                    Share.第四門課程人數++;

                if (目前選課[1] == "第五門課程")
                    Share.第五門課程人數++;
            }

            int 存在索引 = -1;
  

            string[] 所選課程 = 取得選取課程();  // 取得選取的課程

            if (存在索引 == -1)
            {
                MessageBox.Show("查無此學生，請從下拉選單選擇現有學生資料進行修改。",
                     "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            else
            {
              
                Share.S_Photos_array[存在索引] = 暫存圖片路徑;

                // 儲存選課
                儲存選課(所選課程, 存在索引);

                MessageBox.Show("已更新: " + cboName.Text + " 的資料",
                    "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // 清空表單
            pictureBox.BackgroundImage = null;
            暫存圖片路徑 = "";
            cboName.Text = "";
            lblNumber.Text = "";
            lblGender.Text = "";


            checkBox第一門課程.Checked = false;
            checkBox第二門課程.Checked = false;
            checkBox第三門課程.Checked = false;
            checkBox第四門課程.Checked = false;
            checkBox第五門課程.Checked = false;
        }


        private void frm學生建檔_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;  // 防止表單被銷毀
            this.Hide();      // 隱藏表單而不是關閉
        }


        private void 已建檔名單ToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            Server_Share.學生建檔名單.更新表格資料();  // <<== 加這行，重新整理內容
            frm學生建檔名單 學生建檔名單 = new frm學生建檔名單();
            學生建檔名單.Show();

        }


        private void 使用說明ToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MessageBox.Show("使用說明:/n✅ 可從 ComboBox 選擇已有學生，更新性別、學號、照片/n" +
                "(自動載入學號、性別、照片供修改)/n" +
                "✅ 可新增學生建檔資料:姓名、學號、性別與照片，完成後可至『查看名單』中確認",
                  "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void cboName_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = -1;
            for (int i = 0; i < Share.S_i; i++)
            {
                if (Share.S_Names_array[i] == cboName.Text)
                {
                    index = i;
                    break;
                }
            }

            if (index != -1)
            {
                // 更新學號與性別
                lblNumber.Text = Share.S_Numbers_array[index];
                lblGender.Text = Share.S_Genders_array[index];

                暫存圖片路徑 = Share.S_Photos_array[index];

                // 顯示圖片與圖片資訊
                if (File.Exists(暫存圖片路徑))
                {
                    Image img = Image.FromFile(暫存圖片路徑);
                    pictureBox.BackgroundImage = img;
                    lbl_尺寸.Text = img.Width + " x " + img.Height;
                    FileInfo info = new FileInfo(暫存圖片路徑);
                    lbl_大小.Text = (info.Length / 1024.0).ToString("F2") + " KB";
                }
                else
                {
                    pictureBox.BackgroundImage = null;
                    lbl_尺寸.Text = "";
                    lbl_大小.Text = "";
                }
            }
        }

        
    }
}


