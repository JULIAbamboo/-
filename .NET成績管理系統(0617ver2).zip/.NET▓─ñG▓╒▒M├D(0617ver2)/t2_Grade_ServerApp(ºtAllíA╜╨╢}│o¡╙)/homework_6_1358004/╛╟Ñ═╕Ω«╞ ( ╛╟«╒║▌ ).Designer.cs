﻿namespace homework_6_1358004
{
    partial class frm學生建檔
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm學生建檔));
            this.Dialog打開資料夾 = new System.Windows.Forms.OpenFileDialog();
            this.cboName = new System.Windows.Forms.ComboBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.回至開發人員測試頁面ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.使用說明ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.已建檔名單ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.btn選擇檔案 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbl_大小 = new System.Windows.Forms.Label();
            this.lbl_尺寸 = new System.Windows.Forms.Label();
            this.lbl大小 = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.lbl尺寸 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox第一門課程 = new System.Windows.Forms.CheckBox();
            this.checkBox第二門課程 = new System.Windows.Forms.CheckBox();
            this.checkBox第三門課程 = new System.Windows.Forms.CheckBox();
            this.checkBox第四門課程 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBox第五門課程 = new System.Windows.Forms.CheckBox();
            this.lblNumber = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // Dialog打開資料夾
            // 
            this.Dialog打開資料夾.FileName = "openFileDialog1";
            // 
            // cboName
            // 
            this.cboName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboName.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.cboName.FormattingEnabled = true;
            this.cboName.Items.AddRange(new object[] {
            "藍晨祐",
            "林柔宥",
            "葉哲銘",
            "黃姿穎"});
            this.cboName.Location = new System.Drawing.Point(111, 56);
            this.cboName.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.cboName.Name = "cboName";
            this.cboName.Size = new System.Drawing.Size(153, 29);
            this.cboName.TabIndex = 18;
            this.cboName.SelectedIndexChanged += new System.EventHandler(this.cboName_SelectedIndexChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.使用說明ToolStripMenuItem,
            this.toolStripMenuItem2,
            this.已建檔名單ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(558, 26);
            this.menuStrip1.TabIndex = 25;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.回至開發人員測試頁面ToolStripMenuItem});
            this.toolStripMenuItem1.Font = new System.Drawing.Font("Microsoft JhengHei UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(32, 24);
            this.toolStripMenuItem1.Text = "☰";
            // 
            // 回至開發人員測試頁面ToolStripMenuItem
            // 
            this.回至開發人員測試頁面ToolStripMenuItem.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.回至開發人員測試頁面ToolStripMenuItem.Name = "回至開發人員測試頁面ToolStripMenuItem";
            this.回至開發人員測試頁面ToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.回至開發人員測試頁面ToolStripMenuItem.Text = "開發人員測試頁面";
            this.回至開發人員測試頁面ToolStripMenuItem.Click += new System.EventHandler(this.回至開發人員測試頁面ToolStripMenuItem_Click);
            // 
            // 使用說明ToolStripMenuItem
            // 
            this.使用說明ToolStripMenuItem.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.使用說明ToolStripMenuItem.Name = "使用說明ToolStripMenuItem";
            this.使用說明ToolStripMenuItem.Size = new System.Drawing.Size(83, 24);
            this.使用說明ToolStripMenuItem.Text = "使用說明";
            this.使用說明ToolStripMenuItem.Click += new System.EventHandler(this.使用說明ToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.BackColor = System.Drawing.Color.Transparent;
            this.toolStripMenuItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripMenuItem2.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(75, 24);
            this.toolStripMenuItem2.Text = "💾 儲存";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // 已建檔名單ToolStripMenuItem
            // 
            this.已建檔名單ToolStripMenuItem.BackColor = System.Drawing.Color.Transparent;
            this.已建檔名單ToolStripMenuItem.CheckOnClick = true;
            this.已建檔名單ToolStripMenuItem.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.已建檔名單ToolStripMenuItem.Name = "已建檔名單ToolStripMenuItem";
            this.已建檔名單ToolStripMenuItem.Size = new System.Drawing.Size(105, 24);
            this.已建檔名單ToolStripMenuItem.Text = "📄 查看名單";
            this.已建檔名單ToolStripMenuItem.Click += new System.EventHandler(this.已建檔名單ToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.AllowDrop = true;
            this.panel1.BackColor = System.Drawing.Color.Gainsboro;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.btn選擇檔案);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(40, 273);
            this.panel1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(474, 132);
            this.panel1.TabIndex = 26;
            this.panel1.DragDrop += new System.Windows.Forms.DragEventHandler(this.panel1_DragDrop);
            this.panel1.DragEnter += new System.Windows.Forms.DragEventHandler(this.panel1_DragEnter);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("標楷體", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label8.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label8.Location = new System.Drawing.Point(225, 51);
            this.label8.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(49, 19);
            this.label8.TabIndex = 46;
            this.label8.Text = "-或-";
            // 
            // btn選擇檔案
            // 
            this.btn選擇檔案.BackColor = System.Drawing.Color.LightSlateGray;
            this.btn選擇檔案.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn選擇檔案.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn選擇檔案.ForeColor = System.Drawing.Color.Transparent;
            this.btn選擇檔案.Location = new System.Drawing.Point(159, 81);
            this.btn選擇檔案.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.btn選擇檔案.Name = "btn選擇檔案";
            this.btn選擇檔案.Size = new System.Drawing.Size(182, 38);
            this.btn選擇檔案.TabIndex = 18;
            this.btn選擇檔案.Text = "選取裝置中的檔案";
            this.btn選擇檔案.UseVisualStyleBackColor = false;
            this.btn選擇檔案.Click += new System.EventHandler(this.btn選擇檔案_Click_1);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label7.Location = new System.Drawing.Point(155, 16);
            this.label7.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(186, 22);
            this.label7.TabIndex = 45;
            this.label7.Text = "將檔案拖曳至這裡";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(36, 60);
            this.label1.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 22);
            this.label1.TabIndex = 27;
            this.label1.Text = "姓名 ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(36, 115);
            this.label2.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 22);
            this.label2.TabIndex = 28;
            this.label2.Text = "學號 ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(36, 172);
            this.label3.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 22);
            this.label3.TabIndex = 29;
            this.label3.Text = "性別 ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(36, 230);
            this.label5.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 22);
            this.label5.TabIndex = 32;
            this.label5.Text = "照片上傳";
            // 
            // lbl_大小
            // 
            this.lbl_大小.AutoSize = true;
            this.lbl_大小.BackColor = System.Drawing.Color.Transparent;
            this.lbl_大小.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_大小.ForeColor = System.Drawing.Color.Black;
            this.lbl_大小.Location = new System.Drawing.Point(340, 122);
            this.lbl_大小.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_大小.Name = "lbl_大小";
            this.lbl_大小.Size = new System.Drawing.Size(81, 20);
            this.lbl_大小.TabIndex = 43;
            this.lbl_大小.Text = "                  ";
            // 
            // lbl_尺寸
            // 
            this.lbl_尺寸.AutoSize = true;
            this.lbl_尺寸.BackColor = System.Drawing.Color.Transparent;
            this.lbl_尺寸.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl_尺寸.ForeColor = System.Drawing.Color.Black;
            this.lbl_尺寸.Location = new System.Drawing.Point(340, 63);
            this.lbl_尺寸.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl_尺寸.Name = "lbl_尺寸";
            this.lbl_尺寸.Size = new System.Drawing.Size(69, 20);
            this.lbl_尺寸.TabIndex = 42;
            this.lbl_尺寸.Text = "               ";
            // 
            // lbl大小
            // 
            this.lbl大小.AutoSize = true;
            this.lbl大小.BackColor = System.Drawing.Color.Transparent;
            this.lbl大小.Font = new System.Drawing.Font("標楷體", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl大小.ForeColor = System.Drawing.Color.Black;
            this.lbl大小.Location = new System.Drawing.Point(274, 124);
            this.lbl大小.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl大小.Name = "lbl大小";
            this.lbl大小.Size = new System.Drawing.Size(59, 19);
            this.lbl大小.TabIndex = 39;
            this.lbl大小.Text = "大小:";
            // 
            // pictureBox
            // 
            this.pictureBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox.BackgroundImage")));
            this.pictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox.Location = new System.Drawing.Point(65, 32);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(147, 137);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox.TabIndex = 36;
            this.pictureBox.TabStop = false;
            // 
            // lbl尺寸
            // 
            this.lbl尺寸.AutoSize = true;
            this.lbl尺寸.BackColor = System.Drawing.Color.Transparent;
            this.lbl尺寸.Font = new System.Drawing.Font("標楷體", 13.875F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lbl尺寸.ForeColor = System.Drawing.Color.Black;
            this.lbl尺寸.Location = new System.Drawing.Point(274, 65);
            this.lbl尺寸.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lbl尺寸.Name = "lbl尺寸";
            this.lbl尺寸.Size = new System.Drawing.Size(59, 19);
            this.lbl尺寸.TabIndex = 38;
            this.lbl尺寸.Text = "尺寸:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox);
            this.groupBox1.Controls.Add(this.lbl尺寸);
            this.groupBox1.Controls.Add(this.lbl_尺寸);
            this.groupBox1.Controls.Add(this.lbl_大小);
            this.groupBox1.Controls.Add(this.lbl大小);
            this.groupBox1.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(40, 434);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.groupBox1.Size = new System.Drawing.Size(474, 185);
            this.groupBox1.TabIndex = 45;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "預覽";
            // 
            // checkBox第一門課程
            // 
            this.checkBox第一門課程.AutoSize = true;
            this.checkBox第一門課程.BackColor = System.Drawing.Color.Transparent;
            this.checkBox第一門課程.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox第一門課程.Location = new System.Drawing.Point(106, 32);
            this.checkBox第一門課程.Name = "checkBox第一門課程";
            this.checkBox第一門課程.Size = new System.Drawing.Size(106, 20);
            this.checkBox第一門課程.TabIndex = 48;
            this.checkBox第一門課程.Text = "第一門課程";
            this.checkBox第一門課程.UseVisualStyleBackColor = false;
            // 
            // checkBox第二門課程
            // 
            this.checkBox第二門課程.AutoSize = true;
            this.checkBox第二門課程.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox第二門課程.Location = new System.Drawing.Point(106, 58);
            this.checkBox第二門課程.Name = "checkBox第二門課程";
            this.checkBox第二門課程.Size = new System.Drawing.Size(106, 20);
            this.checkBox第二門課程.TabIndex = 49;
            this.checkBox第二門課程.Text = "第二門課程";
            this.checkBox第二門課程.UseVisualStyleBackColor = true;
            // 
            // checkBox第三門課程
            // 
            this.checkBox第三門課程.AutoSize = true;
            this.checkBox第三門課程.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox第三門課程.Location = new System.Drawing.Point(106, 84);
            this.checkBox第三門課程.Name = "checkBox第三門課程";
            this.checkBox第三門課程.Size = new System.Drawing.Size(106, 20);
            this.checkBox第三門課程.TabIndex = 50;
            this.checkBox第三門課程.Text = "第三門課程";
            this.checkBox第三門課程.UseVisualStyleBackColor = true;
            // 
            // checkBox第四門課程
            // 
            this.checkBox第四門課程.AutoSize = true;
            this.checkBox第四門課程.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox第四門課程.Location = new System.Drawing.Point(106, 110);
            this.checkBox第四門課程.Name = "checkBox第四門課程";
            this.checkBox第四門課程.Size = new System.Drawing.Size(106, 20);
            this.checkBox第四門課程.TabIndex = 51;
            this.checkBox第四門課程.Text = "第四門課程";
            this.checkBox第四門課程.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.checkBox第一門課程);
            this.groupBox2.Controls.Add(this.checkBox第四門課程);
            this.groupBox2.Controls.Add(this.checkBox第二門課程);
            this.groupBox2.Controls.Add(this.checkBox第三門課程);
            this.groupBox2.Font = new System.Drawing.Font("標楷體", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox2.Location = new System.Drawing.Point(293, 56);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(230, 168);
            this.groupBox2.TabIndex = 52;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "課程";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(4, 59);
            this.label6.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 32);
            this.label6.TabIndex = 53;
            this.label6.Text = "*請勾選課程\r\n(可複選)";
            // 
            // checkBox第五門課程
            // 
            this.checkBox第五門課程.AutoSize = true;
            this.checkBox第五門課程.Font = new System.Drawing.Font("標楷體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.checkBox第五門課程.Location = new System.Drawing.Point(399, 192);
            this.checkBox第五門課程.Name = "checkBox第五門課程";
            this.checkBox第五門課程.Size = new System.Drawing.Size(106, 20);
            this.checkBox第五門課程.TabIndex = 54;
            this.checkBox第五門課程.Text = "第五門課程";
            this.checkBox第五門課程.UseVisualStyleBackColor = true;
            // 
            // lblNumber
            // 
            this.lblNumber.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNumber.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblNumber.Location = new System.Drawing.Point(111, 110);
            this.lblNumber.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblNumber.Name = "lblNumber";
            this.lblNumber.Size = new System.Drawing.Size(155, 30);
            this.lblNumber.TabIndex = 55;
            this.lblNumber.Text = "            ";
            this.lblNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblGender
            // 
            this.lblGender.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblGender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGender.Font = new System.Drawing.Font("標楷體", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblGender.Location = new System.Drawing.Point(111, 167);
            this.lblGender.Margin = new System.Windows.Forms.Padding(1, 0, 1, 0);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(155, 30);
            this.lblGender.TabIndex = 56;
            this.lblGender.Text = "            ";
            this.lblGender.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // frm學生建檔
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 644);
            this.Controls.Add(this.lblGender);
            this.Controls.Add(this.lblNumber);
            this.Controls.Add(this.checkBox第五門課程);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cboName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("標楷體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(1, 2, 1, 2);
            this.Name = "frm學生建檔";
            this.Text = "學生建檔 ( 學校端 )";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frm學生建檔_FormClosing);
            this.Load += new System.EventHandler(this.frm學生建檔_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog Dialog打開資料夾;
        private System.Windows.Forms.ComboBox cboName;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn選擇檔案;
        private System.Windows.Forms.ToolStripMenuItem 回至開發人員測試頁面ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbl_大小;
        private System.Windows.Forms.Label lbl_尺寸;
        private System.Windows.Forms.Label lbl大小;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.Label lbl尺寸;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem 已建檔名單ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 使用說明ToolStripMenuItem;
        private System.Windows.Forms.CheckBox checkBox第一門課程;
        private System.Windows.Forms.CheckBox checkBox第二門課程;
        private System.Windows.Forms.CheckBox checkBox第三門課程;
        private System.Windows.Forms.CheckBox checkBox第四門課程;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBox第五門課程;
        private System.Windows.Forms.Label lblNumber;
        private System.Windows.Forms.Label lblGender;
    }
}