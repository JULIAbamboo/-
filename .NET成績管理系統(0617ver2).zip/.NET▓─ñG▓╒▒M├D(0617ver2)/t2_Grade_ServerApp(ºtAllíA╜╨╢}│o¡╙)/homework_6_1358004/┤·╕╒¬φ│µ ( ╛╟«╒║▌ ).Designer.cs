﻿namespace homework_6_1358004
{
    partial class frm測試表單_學校端
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm測試表單_學校端));
            this.btn成績套用 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btn成績套用_不及格 = new System.Windows.Forms.Button();
            this.btn還原預設 = new System.Windows.Forms.Button();
            this.btn首頁 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn成績套用
            // 
            this.btn成績套用.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn成績套用.Location = new System.Drawing.Point(16, 23);
            this.btn成績套用.Name = "btn成績套用";
            this.btn成績套用.Size = new System.Drawing.Size(137, 55);
            this.btn成績套用.TabIndex = 3;
            this.btn成績套用.Text = "成績套用";
            this.btn成績套用.UseVisualStyleBackColor = true;
            this.btn成績套用.Click += new System.EventHandler(this.btn成績套用_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btn成績套用_不及格);
            this.groupBox1.Controls.Add(this.btn成績套用);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Location = new System.Drawing.Point(188, 10);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.groupBox1.Size = new System.Drawing.Size(170, 175);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // btn成績套用_不及格
            // 
            this.btn成績套用_不及格.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn成績套用_不及格.Location = new System.Drawing.Point(16, 102);
            this.btn成績套用_不及格.Name = "btn成績套用_不及格";
            this.btn成績套用_不及格.Size = new System.Drawing.Size(137, 55);
            this.btn成績套用_不及格.TabIndex = 6;
            this.btn成績套用_不及格.Text = "成績套用\r\n(不及格)";
            this.btn成績套用_不及格.UseVisualStyleBackColor = true;
            this.btn成績套用_不及格.Click += new System.EventHandler(this.btn成績套用_不及格_Click);
            // 
            // btn還原預設
            // 
            this.btn還原預設.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn還原預設.Location = new System.Drawing.Point(29, 112);
            this.btn還原預設.Name = "btn還原預設";
            this.btn還原預設.Size = new System.Drawing.Size(137, 55);
            this.btn還原預設.TabIndex = 5;
            this.btn還原預設.Text = "還原預設";
            this.btn還原預設.UseVisualStyleBackColor = true;
            this.btn還原預設.Click += new System.EventHandler(this.btn還原預設_Click);
            // 
            // btn首頁
            // 
            this.btn首頁.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn首頁.Location = new System.Drawing.Point(29, 33);
            this.btn首頁.Name = "btn首頁";
            this.btn首頁.Size = new System.Drawing.Size(137, 55);
            this.btn首頁.TabIndex = 6;
            this.btn首頁.Text = "首頁";
            this.btn首頁.UseVisualStyleBackColor = true;
            this.btn首頁.Click += new System.EventHandler(this.btn首頁_Click);
            // 
            // frm測試表單_學校端
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(367, 189);
            this.Controls.Add(this.btn首頁);
            this.Controls.Add(this.btn還原預設);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frm測試表單_學校端";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "測試 ( 學校端 )";
            this.Load += new System.EventHandler(this.frm測試表單_學校端_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btn成績套用;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btn還原預設;
        private System.Windows.Forms.Button btn成績套用_不及格;
        private System.Windows.Forms.Button btn首頁;
    }
}